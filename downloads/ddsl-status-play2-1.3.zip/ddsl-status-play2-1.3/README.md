This is a web applications showing all online Services in [DDSL](https://github.com/mbknor/ddsl)

It is a [Play Framework 2](http://www.playframework.org/) application


You can start it like a regular play app or download [ddsl-status-play2-1.3.zip](http://mbknor.github.com/downloads/ddsl-status-play2-1.3.zip) and start it like this:

    unzip ddsl-status-play2-1.3.zip
    cd ddsl-status-play2-1.3
    chmod u+x start
    ./start

The point your browser to

	http://localhost:9000/
	

	